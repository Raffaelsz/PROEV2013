plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.santos.pes2013launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.santos.pes2013launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "1.5.1-dev"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
