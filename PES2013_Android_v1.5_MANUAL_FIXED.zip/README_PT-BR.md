# PES 2013 Android v1.5.1 DEV — base de interface

## Compilar pelo GitHub
1. Extraia este ZIP no celular ou computador.
2. Envie o **conteúdo** da pasta do projeto para a raiz de um repositório GitHub (não envie o ZIP como único arquivo).
3. Confirme que `.github/workflows/android.yml` está no caminho exato, na branch principal.
4. Abra **Actions** → **Gerar APK PES 2013 v1.5.1 DEV** → **Run workflow**.
5. Quando a execução terminar com sucesso, baixe o APK em **Artifacts**.

## Importante
Esta versão corrige a incompatibilidade de alvo JVM Java/Kotlin (ambos em 17) que apareceu no log. A compilação ainda precisa ser executada no GitHub para confirmar se não há outros erros.

Este projeto é uma interface/launcher experimental com diagnóstico de arquivo. **Não contém um motor nativo para executar PES 2013 de Xbox 360 no Android.** Gerar um APK não significa que o jogo já esteja recompilado ou jogável nativamente.
